package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import org.example.model.Author;
import org.example.model.Book;
import org.example.model.Genre;
import org.example.model.PublishingHouse;
import org.example.repository.AuthorsRepository;

import java.io.IOException;
import java.util.logging.*;

public class Main {
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("books-unit");
        EntityManager em = emf.createEntityManager();

        EntityTransaction transaction = em.getTransaction();
        transaction.begin();

        // Create an author
        Author author = new Author("Author Name");
        em.persist(author);

        // Create two genres
        Genre genre1 = new Genre("Genre 1");
        Genre genre2 = new Genre("Genre 2");
        em.persist(genre1);
        em.persist(genre2);

        // Create a book
        Book book = new Book("Book Title", "English", "2023-01-01", 100);
        book.addAuthor(author);
        book.addGenre(genre1);
        book.addGenre(genre2);
        em.persist(book);

        // Create a publishing house
        PublishingHouse publishingHouse = new PublishingHouse("Publishing House Name");
        publishingHouse.getBooks().add(book);
        em.persist(publishingHouse);

        transaction.commit();

        em.close();
        emf.close();
    }
}